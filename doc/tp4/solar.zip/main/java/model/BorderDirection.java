package model;

/**
 * Created by leonelbadi on 9/4/16.
 */
public enum BorderDirection {

    HORIZONTAL,VERTICAL
}
